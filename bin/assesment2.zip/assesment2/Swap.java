package assesment2;

public class Swap {
	String emp1,emp2;
	public Swap() {
	emp1= "this is A";
	emp2= "this is B";
}
	public swap(string x, string y) {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
