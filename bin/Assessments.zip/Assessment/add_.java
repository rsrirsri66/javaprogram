package Assessment;

import java.util.Scanner;

public class add_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int a,b,c,add;
      Scanner s=new Scanner(System.in);
      System.out.print("a=");
      a=s.nextInt();
      System.out.print("b=");
      b=s.nextInt();
      System.out.print("c=");
      c=s.nextInt();
      add=a+b+c;
      System.out.print(add);
	}

}
