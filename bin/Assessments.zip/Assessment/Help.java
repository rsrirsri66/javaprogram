package Assessment;

import java.util.Scanner;

public class Help {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int m=6,n=2;
		if(m%n==0) {
			System.out.print("1");
		}
		else {
			System.out.print("0");
		}

	}

}
