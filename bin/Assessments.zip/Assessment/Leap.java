package Assessment;

import java.util.Scanner;

public class Leap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int year;
		Scanner s=new Scanner(System.in);
		 System.out.print("year=");
	     year=s.nextInt();
	     if(year%4==0) {
	    	 System.out.print("YES");
	     } else {
	    		 System.out.print("NO");
	    	 }
	     }

	

}
